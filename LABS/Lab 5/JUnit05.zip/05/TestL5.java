public class TestL5 {

   public static void main(String[] args) {
    TestUtils.runClass(TestL5Book.class);
    TestUtils.runClass(TestL5Library.class);

    TestUtils.runClass(TestL5Arithmetic.class);
    TestUtils.runClass(TestL5Geometric.class);
  }

}
