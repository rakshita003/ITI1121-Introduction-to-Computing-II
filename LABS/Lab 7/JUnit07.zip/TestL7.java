public class TestL7 {

    public static void main(String[] args) {
        TestUtils.runClass(TestL7Exercise1.class);
        TestUtils.runClass(TestL7Account.class);
        TestUtils.runClass(TestL7ArrayStack.class);
        TestUtils.runClass(TestL7DynamicArrayStack.class);
        TestUtils.runClass(TestL7Dictionary.class);
    }

}
