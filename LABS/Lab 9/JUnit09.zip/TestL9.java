public class TestL9 {

    public static void main(String[] args) {
        TestUtils.runClass(TestL9SecretMessage.class);
        TestUtils.runClass(TestL9PlayList.class);
    }

}
